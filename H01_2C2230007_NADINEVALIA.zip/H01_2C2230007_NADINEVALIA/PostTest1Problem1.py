# Nadine Valia Azzahra 2C2230007
# 14 Oktober 2024
# Problem 1 (program menentukan barang jual dengan keuntungan terbesar)

# input harga dasar dan harga jual barang A
harga_dasar_A = int(input("Masukkan harga dasar barang A: "))
harga_jual_A = int(input("Masukkan harga jual barang A: "))

# input harga dasar dan harga jual barang B
harga_dasar_B = int(input("Masukkan harga dasar barang B: "))
harga_jual_B = int(input("Masukkan harga jual barang B: "))

# input harga dasar dan harga jual barang C
harga_dasar_C = int(input("Masukkan harga dasar barang C: "))
harga_jual_C = int(input("Masukkan harga jual barang C: "))

# hitung keuntungan untuk masing-masing barang
keuntungan_A = harga_jual_A - harga_dasar_A
keuntungan_B = harga_jual_B - harga_dasar_B
keuntungan_C = harga_jual_C - harga_dasar_C

# menentukan barang dengan keuntungan terbesar
if keuntungan_A > keuntungan_B and keuntungan_A > keuntungan_C:
    print("Barang yang harus ditawarkan adalah barang A")
elif keuntungan_B > keuntungan_A and keuntungan_B > keuntungan_C:
    print("Barang yang harus ditawarkan adalah barang B")
else:

# menampilkan hasil
    print("Barang yang harus ditawarkan adalah barang C")